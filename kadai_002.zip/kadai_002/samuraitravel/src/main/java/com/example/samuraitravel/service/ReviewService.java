package com.example.samuraitravel.service;

import java.sql.Timestamp;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.example.samuraitravel.entity.House;
import com.example.samuraitravel.entity.Review;
import com.example.samuraitravel.entity.User;
import com.example.samuraitravel.form.ReviewEditForm;
import com.example.samuraitravel.form.ReviewPostForm;
import com.example.samuraitravel.repository.HouseRepository;
import com.example.samuraitravel.repository.ReviewRepository;

@Service
public class ReviewService {
	private final ReviewRepository reviewRepository;
	private final HouseRepository houseRepository;

	public ReviewService(ReviewRepository reviewRepository, HouseRepository houseRepository) {
		this.reviewRepository = reviewRepository;
		this.houseRepository = houseRepository;
	}

	// レビューの作成
	@Transactional
	public void reviewCreate(ReviewPostForm reviewPostForm, Integer houseId, User user) {

		// 民宿を取得  
		House house = houseRepository.getReferenceById(houseId);
		
		// 新しいReviewエンティティのインスタンスを作成  
		Review review = new Review();

		review.setHouse(house); // 民宿を設定
		review.setUser(user); // ユーザーを設定  
		review.setRating(reviewPostForm.getRating()); // フォームからの評価を設定  
		review.setComment(reviewPostForm.getComment()); // フォームからのコメントを設定  
		review.setPostedAt(new Timestamp(System.currentTimeMillis())); // 現在の日時を設定  

		reviewRepository.save(review); // レビューを保存  
	}

	// レビュー更新
	@Transactional
	public Review reviewUpdate(ReviewEditForm reviewEditForm, Integer houseId, User user) {
		// 民宿を取得  
		House house = houseRepository.getReferenceById(houseId);
		//更新するレビューを取得
		Review review = reviewRepository.getReferenceById(reviewEditForm.getId());

		review.setHouse(house); // 民宿を設定
		review.setUser(user); // ユーザーを設定  
		review.setRating(reviewEditForm.getRating()); // フォームからの評価を設定  
		review.setComment(reviewEditForm.getComment()); // フォームからのコメントを設定  
		review.setPostedAt(new Timestamp(System.currentTimeMillis())); // 現在の日時を設定  

		return reviewRepository.save(review);
	}
	
}
