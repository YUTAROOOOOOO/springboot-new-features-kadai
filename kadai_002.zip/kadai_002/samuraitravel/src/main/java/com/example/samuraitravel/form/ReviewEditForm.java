package com.example.samuraitravel.form;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ReviewEditForm {
	@NotNull
	private Integer id;
	
	@NotNull(message = "星評価を選択してください。")
	@Min(value = 1, message = "評価は星1以上にしてください。")
	@Max(value = 5, message = "評価は星5以下にしてください。")
	private Integer rating;
	
	@NotBlank(message = "レビューコメントを入力してください。")
	private String comment;

}